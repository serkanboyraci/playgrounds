import UIKit

var greeting = "Hello, playground"

var MyNumber = 10 * 5

20 + 10

var internettenGelenEnYeniVeri = 50 //camelCase - Swfitciler bunu kullanır daha çok

var internetten_gelen_en_yeni_veri = 50 //snake_case

let number = 10

number.isMultiple(of: 2)

greeting.count

let firstNumber = 80
let secondNumber = 12
firstNumber / secondNumber

let doubleNumberFirst = 80.0
let doubleNumberSecond = 12.0
doubleNumberFirst / doubleNumberSecond
 

let numbers : Int32 = 35000 //Int i istediğimiz büyüklükte tanımlayabiliriz.32 veya 64 bit büyüklükte.

let kesirli : Float64 = 3.555555 // float64 double, float32 ise floattur.

let Number1 : String
Number1 = String(numbers)

let StringNo = "400"
let integerString = Int(StringNo)
//integerString! + 20
